package com.cg.banking.daoservices;

import java.util.List;

import com.cg.banking.beans.Transaction;
import com.cg.banking.util.BankingDBUtil;

public class TransactionDAOImpl implements TransactionDAO{
	@Override
	public Transaction save(long accountNo, Transaction transaction) {
		transaction.setTransactionId(BankingDBUtil.getTRANSACTION_ID_COUNTER());
		BankingDBUtil.accountDetails.get(accountNo).getTransactions().put(transaction.getTransactionId(),transaction);
		return null;
	}
	@Override
	public boolean update(long accountNo, Transaction transaction) {
		return false;
	}
	@Override
	public Transaction findOne(long accountNo, int transactionId) {
		return null;
	}
	@Override
	public List<Transaction> findAll(long accountNo) {
		return null;
	}
}
