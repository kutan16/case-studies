package com.cg.banking.client;

import java.util.Scanner;

import com.cg.banking.beans.Account;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.daoservices.AccountDAOImpl;
import com.cg.banking.exception.AccountBlockedException;
import com.cg.banking.exception.AccountNotFoundException;
import com.cg.banking.exception.BankingServicesDownException;
import com.cg.banking.exception.InsufficientAmountException;
import com.cg.banking.exception.InvalidAccountTypeException;
import com.cg.banking.exception.InvalidAmountException;
import com.cg.banking.exception.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
import com.cg.banking.util.BankingDBUtil;

public class MainClass {

	public static void main(String[] args) throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException, AccountNotFoundException, AccountBlockedException,InvalidPinNumberException, InsufficientAmountException {
		BankingServices services = new BankingServicesImpl();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your choice");
		System.out.println("1. create Account");
		System.out.println("2. get account details");
		System.out.println("3. get every account details");
		System.out.println("4.deposit amount");
		System.out.println("5.withdraw amount");
		System.out.println("6.transaction details ");
		int n = sc.nextInt();
		switch(n) {
			case 1: 
				System.out.println("Enter the type of account you want to open: 'savings'/'current' ");
				String accountType=sc.next();
				System.out.println("Enter your current Balance");
				long initialBalance=sc.nextLong();
				Account account = services.openAccount(accountType,initialBalance);
				System.out.println("account created");
				System.out.println(account);
				break;
			case 2:
				System.out.println("Enter account no.");
				long accountNumber=sc.nextLong();
				try {
					System.out.println(services.getAccountDetails(accountNumber));
				} 
				catch (AccountNotFoundException e) {
					e.printStackTrace();
				}
				break;
			case 3 : 
				System.out.println(services.getAllAccountDetails());
				break;
			case 4:
				System.out.println("Enter 'accountNo' and 'amount to deposit' ");
				long accountNumber1=sc.nextLong();
				try {
					System.out.println(services.getAccountDetails(accountNumber1));
				} 
				catch (AccountNotFoundException e) {
					e.printStackTrace();
				}
				float amount1 = sc.nextFloat();
				BankingServicesImpl account1 = new BankingServicesImpl();
				account1.depositAmount(accountNumber1, amount1);
				break;
			case 5:
				System.out.println("Enter 'accountNo', 'amount to withdraw' and 'pinNumber'");
				long accountNumber2=sc.nextLong();
				try {
					System.out.println(services.getAccountDetails(accountNumber2));
				} 
				catch (AccountNotFoundException e) {
					e.printStackTrace();
				}
				float amount2=sc.nextFloat();
				int pinNumber = sc.nextInt();
				//BankingDBUtil.getPin();
				BankingServicesImpl account2 = new BankingServicesImpl();
				account2.withdrawAmount(accountNumber2, amount2, pinNumber);
				break;
				
			case 6:
				BankingServicesImpl account3=new BankingServicesImpl();
				System.out.println("Enter account ID");
				long accountNumber3=sc.nextLong();
				try {
					System.out.println(services.getAccountDetails(accountNumber3));
				} 
				catch (AccountNotFoundException e) {
					e.printStackTrace();
				}
				System.out.println(services.getAccountAllTransaction(accountNumber3));
				throw new BankingServicesDownException();
			//break;
			default: 
				System.out.println("enter correct choice");
			}
			System.out.println("1. continue");
			System.out.println("2. exit");
			int i=sc.nextInt();
			if(i==2) {
				System.exit(0);
				}
			main(null);
		}
}

