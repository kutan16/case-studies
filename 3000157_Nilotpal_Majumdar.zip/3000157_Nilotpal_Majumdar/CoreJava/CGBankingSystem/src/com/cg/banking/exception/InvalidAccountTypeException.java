package com.cg.banking.exception;

public class InvalidAccountTypeException extends Exception {
	public InvalidAccountTypeException() {
		super("ACCOUNT TYPE IS INVALID \t");
	}
}
