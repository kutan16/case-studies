package com.cg.banking.exception;

public class InvalidAmountException extends Exception {
	public InvalidAmountException() {
		super("AMOUNT ENTERED IS INVALID \t");
	}
}
