package com.cg.banking.daoservices;

import java.util.ArrayList;
import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.util.BankingDBUtil;

public class AccountDAOImpl implements AccountDAO{
	
	
	@Override
	public Account save(Account account) {
		account.setAccountNo(BankingDBUtil.getACCOUNT_ID_COUNTER());
		BankingDBUtil.account.put((int)account.getAccountNo(), account);
		account.setPinNumber(BankingDBUtil.getPin());
		BankingDBUtil.account.put(account.getPinNumber(), account);
		account.setAccountStatus(BankingDBUtil.getAccountStatus());
		return account;
	}
	@Override
	public boolean update(Account account) {	
		if(BankingDBUtil.account.containsKey(account.getAccountNo())) {
			BankingDBUtil.account.put((int) account.getAccountNo(), account);
		}
		return false;
	}

	@Override
	public Account findOne(int accountNo) {
		return BankingDBUtil.account.get(accountNo);
	}

	@Override
	public List<Account> findAll() {
		return new ArrayList<Account>(BankingDBUtil.account.values());
	}

}
